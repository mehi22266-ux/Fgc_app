import { create } from "zustand";
import { persist } from "zustand/middleware";
import { deletePhotos } from "@/lib/photos";

export type Report = {
  id: string;
  date: string;
  location: string;
  work: string;
  amount: number;
  photos: string[];
  createdAt: number;
};

export type ReportDraft = {
  date: string;
  location: string;
  work: string;
  amount: number;
  photos: string[];
};

type ReportsState = {
  reports: Report[];
  addReport: (draft: ReportDraft) => Report;
  updateReport: (id: string, draft: ReportDraft) => void;
  deleteReport: (id: string) => void;
};

type Persisted = { reports?: Array<Partial<Report> & { id: string }> };

export const useReports = create<ReportsState>()(
  persist(
    (set, get) => ({
      reports: [],
      addReport: (draft) => {
        const report: Report = {
          id: crypto.randomUUID(),
          createdAt: Date.now(),
          ...draft,
          photos: draft.photos ?? [],
        };
        set({ reports: [report, ...get().reports] });
        return report;
      },
      updateReport: (id, draft) => {
        const prev = get().reports.find((r) => r.id === id);
        const nextPhotos = draft.photos ?? [];
        const removed = (prev?.photos ?? []).filter((p) => !nextPhotos.includes(p));
        void deletePhotos(removed);
        set({
          reports: get().reports.map((r) =>
            r.id === id ? { ...r, ...draft, photos: nextPhotos } : r,
          ),
        });
      },
      deleteReport: (id) => {
        const prev = get().reports.find((r) => r.id === id);
        void deletePhotos(prev?.photos ?? []);
        set({ reports: get().reports.filter((r) => r.id !== id) });
      },
    }),
    {
      name: "fgc-reports",
      version: 2,
      partialize: (state) => ({ reports: state.reports }),
      migrate: (state) => {
        const s = (state ?? {}) as Persisted;
        return {
          reports: (s.reports ?? []).map((r) => ({
            id: r.id,
            date: r.date ?? "",
            location: r.location ?? "",
            work: r.work ?? "",
            amount: r.amount ?? 0,
            photos: r.photos ?? [],
            createdAt: r.createdAt ?? 0,
          })),
        };
      },
    },
  ),
);
