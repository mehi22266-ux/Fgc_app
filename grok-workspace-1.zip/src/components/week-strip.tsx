import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { jalaliDay, jalaliMonthYear, weekdayNarrow } from "@/lib/dates";
import { formatTomanCompact } from "@/lib/money";
import { cn } from "@/lib/utils";

type WeekStripProps = {
  dates: string[];
  selected: string;
  today: string;
  totals: Record<string, number>;
  photoDays: Record<string, boolean>;
  onSelect: (iso: string) => void;
  onPrevWeek: () => void;
  onNextWeek: () => void;
  onToday: () => void;
};

export function WeekStrip({
  dates,
  selected,
  today,
  totals,
  photoDays,
  onSelect,
  onPrevWeek,
  onNextWeek,
  onToday,
}: WeekStripProps) {
  const max = Math.max(1, ...dates.map((d) => totals[d] ?? 0));
  const showToday = selected !== today;

  return (
    <section className="rounded-3xl bg-surface p-3 shadow-border">
      <div className="mb-3 flex items-center gap-2">
        <Button
          type="button"
          variant="ghost"
          size="icon-sm"
          onClick={onPrevWeek}
          aria-label="هفته قبل"
        >
          <ChevronRight className="size-5" />
        </Button>
        <div className="flex min-w-0 flex-1 items-center justify-center gap-2">
          <p className="text-sm font-medium">{jalaliMonthYear(selected)}</p>
          {showToday ? (
            <button
              type="button"
              onClick={onToday}
              className="rounded-full bg-accent-soft px-2.5 py-1 text-xs font-medium text-accent transition-colors duration-150 hover:bg-accent hover:text-accent-fg"
            >
              امروز
            </button>
          ) : null}
        </div>
        <Button
          type="button"
          variant="ghost"
          size="icon-sm"
          onClick={onNextWeek}
          aria-label="هفته بعد"
        >
          <ChevronLeft className="size-5" />
        </Button>
      </div>
      <div className="grid grid-cols-7 gap-1">
        {dates.map((iso) => {
          const isSelected = iso === selected;
          const isToday = iso === today;
          const total = totals[iso] ?? 0;
          const bar = total > 0 ? Math.max(18, Math.round((total / max) * 100)) : 0;
          const hasPhoto = Boolean(photoDays[iso]);
          return (
            <button
              key={iso}
              type="button"
              onClick={() => onSelect(iso)}
              className={cn(
                "relative flex min-h-20 flex-col items-center rounded-xl px-0.5 pt-2 pb-1.5 transition-[background-color,color,box-shadow] duration-150",
                isSelected
                  ? "bg-accent text-accent-fg shadow-border"
                  : "text-ink hover:bg-surface-2",
              )}
            >
              {hasPhoto ? (
                <span
                  className={cn(
                    "absolute top-1.5 left-1.5 size-1.5 rounded-full",
                    isSelected ? "bg-accent-fg" : "bg-accent",
                  )}
                  aria-label="دارای عکس"
                />
              ) : null}
              <span className={cn("text-xs", isSelected ? "text-accent-fg/80" : "text-muted")}>
                {weekdayNarrow(iso)}
              </span>
              <span className="mt-1 text-lg leading-none font-medium tabular-nums">
                {jalaliDay(iso)}
              </span>
              <span className="mt-auto flex h-5 w-full items-end justify-center">
                {total > 0 ? (
                  <span
                    className={cn(
                      "block w-5 rounded-full",
                      isSelected ? "bg-accent-fg/70" : "bg-accent/70",
                    )}
                    style={{ height: `${Math.round((bar / 100) * 16) + 3}px` }}
                    title={formatTomanCompact(total)}
                  />
                ) : isToday && !isSelected ? (
                  <span className="mb-0.5 size-1.5 rounded-full bg-accent" />
                ) : null}
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}
