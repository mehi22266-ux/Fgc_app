import { useEffect, useState } from "react";
import { getPhotoBlob } from "@/lib/photos";
import { cn } from "@/lib/utils";

type PhotoThumbProps = {
  id: string;
  alt?: string;
  className?: string;
  onClick?: () => void;
};

export function PhotoThumb({ id, alt = "عکس کار", className, onClick }: PhotoThumbProps) {
  const [src, setSrc] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    let created: string | null = null;
    void getPhotoBlob(id).then((blob) => {
      if (cancelled || !blob) return;
      created = URL.createObjectURL(blob);
      setSrc(created);
    });
    return () => {
      cancelled = true;
      if (created) URL.revokeObjectURL(created);
    };
  }, [id]);

  if (!src) {
    return <div className={cn("animate-pulse bg-surface-2", className)} aria-hidden="true" />;
  }

  return (
    <button
      type="button"
      onClick={onClick}
      className={cn("block overflow-hidden", className)}
      aria-label={alt}
    >
      <img
        src={src}
        alt={alt}
        className="size-full object-cover outline outline-1 -outline-offset-1 outline-ink/10"
      />
    </button>
  );
}
