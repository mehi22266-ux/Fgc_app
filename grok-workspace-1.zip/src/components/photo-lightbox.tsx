import * as DialogPrimitive from "@radix-ui/react-dialog";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { PhotoThumb } from "@/components/photo-thumb";
import { Button } from "@/components/ui/button";
import { DialogOverlay, DialogPortal } from "@/components/ui/dialog";

type PhotoLightboxProps = {
  ids: string[];
  index: number | null;
  onIndex: (index: number | null) => void;
};

export function PhotoLightbox({ ids, index, onIndex }: PhotoLightboxProps) {
  const open = index !== null && ids.length > 0;
  const current = index === null ? 0 : Math.min(index, Math.max(0, ids.length - 1));
  const id = ids[current];

  return (
    <DialogPrimitive.Root
      open={open}
      onOpenChange={(next) => {
        if (!next) onIndex(null);
      }}
    >
      <DialogPortal>
        <DialogOverlay />
        <DialogPrimitive.Content
          className="lightbox-panel fixed top-1/2 left-1/2 z-50 -translate-x-1/2 -translate-y-1/2 rounded-3xl bg-surface p-3 text-ink shadow-dialog data-[state=open]:animate-dialog-in data-[state=closed]:animate-dialog-out"
          aria-describedby={undefined}
        >
          <DialogPrimitive.Title className="sr-only">عکس کار</DialogPrimitive.Title>
          <DialogPrimitive.Close
            className="absolute top-3 left-3 z-10 flex size-9 items-center justify-center rounded-lg bg-bg/70 text-ink transition-colors duration-150 hover:bg-surface-2"
            aria-label="بستن"
          >
            <X className="size-4" />
          </DialogPrimitive.Close>
          {id ? <PhotoThumb id={id} className="aspect-video w-full rounded-xl" /> : null}
          {ids.length > 1 ? (
            <div className="mt-3 flex items-center justify-between gap-2">
              <Button
                type="button"
                variant="secondary"
                size="icon-sm"
                onClick={() => onIndex((current - 1 + ids.length) % ids.length)}
                aria-label="عکس قبلی"
              >
                <ChevronRight className="size-4" />
              </Button>
              <p className="text-sm tabular-nums text-muted">
                {new Intl.NumberFormat("fa-IR").format(current + 1)} از{" "}
                {new Intl.NumberFormat("fa-IR").format(ids.length)}
              </p>
              <Button
                type="button"
                variant="secondary"
                size="icon-sm"
                onClick={() => onIndex((current + 1) % ids.length)}
                aria-label="عکس بعدی"
              >
                <ChevronLeft className="size-4" />
              </Button>
            </div>
          ) : null}
        </DialogPrimitive.Content>
      </DialogPortal>
    </DialogPrimitive.Root>
  );
}
