import { Download, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { ReportCard } from "@/components/report-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { jalaliFull, jalaliMonthYear } from "@/lib/dates";
import { downloadReportsCsv } from "@/lib/export-csv";
import { formatToman } from "@/lib/money";
import type { Report } from "@/store/reports";

type AllReportsProps = {
  reports: Report[];
  onEdit: (report: Report) => void;
  onDelete: (report: Report) => void;
};

export function AllReports({ reports, onEdit, onDelete }: AllReportsProps) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim();
    const list = q
      ? reports.filter(
          (r) => r.location.includes(q) || r.work.includes(q),
        )
      : reports;
    return [...list].sort(
      (a, b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt,
    );
  }, [reports, query]);

  const groups = useMemo(() => {
    const map = new Map<string, Report[]>();
    for (const r of filtered) {
      const key = jalaliMonthYear(r.date);
      const arr = map.get(key);
      if (arr) arr.push(r);
      else map.set(key, [r]);
    }
    return [...map.entries()];
  }, [filtered]);

  const total = filtered.reduce((sum, r) => sum + r.amount, 0);

  return (
    <section className="flex flex-col gap-4">
      <div className="rounded-3xl bg-surface p-3 shadow-border">
        <div className="relative">
          <Search className="pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-subtle" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="جستجو در مکان یا شرح کار"
            className="pr-10"
          />
        </div>
        <div className="mt-3 flex items-center justify-between gap-3 px-1">
          <p className="text-sm text-muted">
            {filtered.length ? (
              <>
                جمع نتایج:{" "}
                <span className="font-medium tabular-nums text-accent">{formatToman(total)}</span>
              </>
            ) : (
              "گزارشی پیدا نشد"
            )}
          </p>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            disabled={reports.length === 0}
            onClick={() => downloadReportsCsv(reports)}
          >
            <Download className="size-3.5" />
            خروجی
          </Button>
        </div>
      </div>

      {groups.length === 0 ? (
        <div className="rounded-3xl bg-surface px-6 py-14 text-center shadow-border">
          <p className="font-medium">هنوز گزارشی ثبت نشده</p>
          <p className="mt-1 text-sm text-muted">از نمای هفته، برای هر روز گزارش کار بنویسید.</p>
        </div>
      ) : (
        groups.map(([month, items]) => (
          <div key={month} className="flex flex-col gap-2">
            <h2 className="px-1 text-sm font-medium text-muted">{month}</h2>
            <div className="rounded-3xl bg-surface p-3 shadow-border">
              <div className="flex flex-col gap-2">
                {items.map((report) => (
                  <ReportCard
                    key={report.id}
                    report={report}
                    showDate={jalaliFull(report.date)}
                    onEdit={onEdit}
                    onDelete={onDelete}
                  />
                ))}
              </div>
            </div>
          </div>
        ))
      )}
    </section>
  );
}
