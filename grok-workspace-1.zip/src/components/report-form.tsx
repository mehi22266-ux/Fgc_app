import { ImagePlus, LoaderCircle, X } from "lucide-react";
import { useEffect, useId, useRef, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { PhotoThumb } from "@/components/photo-thumb";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { jalaliFull } from "@/lib/dates";
import { formatTomanCompact, parseAmount } from "@/lib/money";
import { compressImage, MAX_PHOTOS, savePhoto } from "@/lib/photos";
import type { Report, ReportDraft } from "@/store/reports";

type DraftPhoto = {
  key: string;
  storedId?: string;
  url?: string;
  blob?: Blob;
};

type ReportFormProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  date: string;
  locations: string[];
  editing?: Report | null;
  defaultLocation?: string;
  onSubmit: (draft: ReportDraft) => void;
};

export function ReportForm({
  open,
  onOpenChange,
  date,
  locations,
  editing,
  defaultLocation,
  onSubmit,
}: ReportFormProps) {
  const locId = useId();
  const workId = useId();
  const amountId = useId();
  const listId = useId();
  const fileId = "work-photos";
  const fileRef = useRef<HTMLInputElement>(null);

  const [location, setLocation] = useState("");
  const [work, setWork] = useState("");
  const [amount, setAmount] = useState("");
  const [photos, setPhotos] = useState<DraftPhoto[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    if (editing) {
      setLocation(editing.location);
      setWork(editing.work);
      setAmount(formatTomanCompact(editing.amount));
      setPhotos((editing.photos ?? []).map((id) => ({ key: id, storedId: id })));
    } else {
      setLocation(defaultLocation ?? "");
      setWork("");
      setAmount("");
      setPhotos([]);
    }
    setError("");
    setBusy(false);
  }, [open, editing, defaultLocation]);

  async function handleFiles(list: FileList | null) {
    if (!list?.length) return;
    const room = MAX_PHOTOS - photos.length;
    if (room <= 0) {
      toast(`حداکثر ${toFa(MAX_PHOTOS)} عکس برای هر گزارش`);
      return;
    }
    const files = [...list].filter((f) => f.type.startsWith("image/")).slice(0, room);
    if (files.length === 0) {
      setError("فقط فایل عکس انتخاب کنید.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const next: DraftPhoto[] = [];
      for (const file of files) {
        const blob = await compressImage(file);
        next.push({
          key: crypto.randomUUID(),
          blob,
          url: URL.createObjectURL(blob),
        });
      }
      setPhotos((prev) => [...prev, ...next]);
    } catch {
      setError("آماده‌سازی عکس انجام نشد. دوباره تلاش کنید.");
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  function removePhoto(key: string) {
    setPhotos((prev) => {
      const target = prev.find((p) => p.key === key);
      if (target?.url) URL.revokeObjectURL(target.url);
      return prev.filter((p) => p.key !== key);
    });
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const loc = location.trim();
    const done = work.trim();
    const parsed = parseAmount(amount);
    if (!loc) {
      setError("مکان کار را بنویسید.");
      return;
    }
    if (!done && photos.length === 0) {
      setError("شرح کار را بنویسید یا عکس کار را بگذارید.");
      return;
    }
    if (parsed === null) {
      setError("مبلغ دریافتی را به‌درستی وارد کنید. اگر پولی نگرفته‌اید صفر بگذارید.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const savedIds: string[] = [];
      for (const photo of photos) {
        if (photo.blob) savedIds.push(await savePhoto(photo.blob));
        else if (photo.storedId) savedIds.push(photo.storedId);
      }
      onSubmit({
        date: editing?.date ?? date,
        location: loc,
        work: done,
        amount: parsed,
        photos: savedIds,
      });
      onOpenChange(false);
    } catch {
      setError("ذخیره عکس‌ها انجام نشد. دوباره تلاش کنید.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogTitle className="pe-8 text-lg font-semibold">
          {editing ? "ویرایش گزارش" : "ثبت گزارش کار"}
        </DialogTitle>
        <DialogDescription className="mt-1 text-sm text-muted">
          {jalaliFull(editing?.date ?? date)}
        </DialogDescription>
        <form className="mt-5 flex flex-col gap-4" onSubmit={(e) => void handleSubmit(e)}>
          <div className="flex flex-col gap-2">
            <Label htmlFor={locId}>مکان کار</Label>
            <Input
              id={locId}
              list={listId}
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="مثلاً کارگاه ونک"
              autoComplete="off"
            />
            <datalist id={listId}>
              {locations.map((loc) => (
                <option key={loc} value={loc} />
              ))}
            </datalist>
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor={workId}>کار انجام‌شده</Label>
            <Textarea
              id={workId}
              value={work}
              onChange={(e) => setWork(e.target.value)}
              placeholder="توضیح بنویسید، یا فقط عکس کار را پایین بگذارید"
            />
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor={fileId}>عکس کار</Label>
            {photos.length > 0 ? (
              <div className="grid grid-cols-3 gap-2">
                {photos.map((photo) => (
                  <div key={photo.key} className="relative">
                    {photo.url ? (
                      <img
                        src={photo.url}
                        alt=""
                        className="aspect-square w-full rounded-xl object-cover outline outline-1 -outline-offset-1 outline-ink/10"
                      />
                    ) : photo.storedId ? (
                      <PhotoThumb
                        id={photo.storedId}
                        className="aspect-square w-full rounded-xl"
                      />
                    ) : null}
                    <button
                      type="button"
                      onClick={() => removePhoto(photo.key)}
                      className="absolute top-1 left-1 flex size-8 items-center justify-center rounded-lg bg-bg/80 text-ink"
                      aria-label="حذف عکس"
                    >
                      <X className="size-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            ) : null}
            <input
              ref={fileRef}
              id={fileId}
              type="file"
              accept="image/*"
              multiple
              className="sr-only"
              onChange={(e) => void handleFiles(e.target.files)}
            />
            <Button
              type="button"
              variant="outline"
              disabled={busy || photos.length >= MAX_PHOTOS}
              onClick={() => fileRef.current?.click()}
            >
              {busy ? <LoaderCircle className="size-4 animate-spin" /> : <ImagePlus className="size-4" />}
              {photos.length >= MAX_PHOTOS
                ? `حداکثر ${toFa(MAX_PHOTOS)} عکس`
                : "افزودن عکس از دوربین یا گالری"}
            </Button>
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor={amountId}>مبلغ دریافتی (تومان)</Label>
            <Input
              id={amountId}
              inputMode="numeric"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="۰"
              className="tabular-nums"
            />
          </div>
          {error ? (
            <p className="rounded-xl bg-danger-soft px-3 py-2 text-sm text-danger" role="alert">
              {error}
            </p>
          ) : null}
          <div className="mt-1 flex gap-2">
            <Button type="submit" className="flex-1" disabled={busy}>
              ذخیره گزارش
            </Button>
            <Button type="button" variant="secondary" className="flex-1" onClick={() => onOpenChange(false)}>
              انصراف
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function toFa(n: number): string {
  return new Intl.NumberFormat("fa-IR").format(n);
}
