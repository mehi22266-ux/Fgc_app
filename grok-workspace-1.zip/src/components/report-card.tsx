import { MapPin, Pencil, Trash2 } from "lucide-react";
import { useState } from "react";
import { PhotoLightbox } from "@/components/photo-lightbox";
import { PhotoThumb } from "@/components/photo-thumb";
import { Button } from "@/components/ui/button";
import { formatToman } from "@/lib/money";
import type { Report } from "@/store/reports";

type ReportCardProps = {
  report: Report;
  onEdit: (report: Report) => void;
  onDelete: (report: Report) => void;
  showDate?: string;
};

export function ReportCard({ report, onEdit, onDelete, showDate }: ReportCardProps) {
  const [lightbox, setLightbox] = useState<number | null>(null);
  const photos = report.photos ?? [];

  return (
    <article className="rounded-xl bg-surface-2 p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          {showDate ? (
            <p className="mb-1 text-xs font-medium text-muted">{showDate}</p>
          ) : null}
          <p className="flex items-center gap-1.5 text-sm font-medium">
            <MapPin className="size-3.5 shrink-0 text-accent" strokeWidth={2} />
            <span className="truncate">{report.location}</span>
          </p>
        </div>
        <p className="shrink-0 text-base font-semibold tabular-nums text-accent">
          {formatToman(report.amount)}
        </p>
      </div>
      {report.work ? (
        <p className="mt-2 text-sm leading-relaxed text-muted">{report.work}</p>
      ) : null}
      {photos.length > 0 ? (
        <div className="mt-3 grid grid-cols-3 gap-1.5">
          {photos.map((id, i) => (
            <PhotoThumb
              key={id}
              id={id}
              className="aspect-square rounded-lg"
              onClick={() => setLightbox(i)}
            />
          ))}
        </div>
      ) : null}
      <div className="mt-3 flex gap-1">
        <Button type="button" variant="ghost" size="sm" onClick={() => onEdit(report)}>
          <Pencil className="size-3.5" />
          ویرایش
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="text-danger hover:bg-danger-soft hover:text-danger"
          onClick={() => onDelete(report)}
        >
          <Trash2 className="size-3.5" />
          حذف
        </Button>
      </div>
      <PhotoLightbox ids={photos} index={lightbox} onIndex={setLightbox} />
    </article>
  );
}
