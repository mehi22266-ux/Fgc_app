import { ClipboardList, Plus } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { AllReports } from "@/components/all-reports";
import { ReportCard } from "@/components/report-card";
import { ReportForm } from "@/components/report-form";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { WeekStrip } from "@/components/week-strip";
import {
  addDays,
  jalaliFull,
  localISO,
  sameJalaliMonth,
  weekDates,
} from "@/lib/dates";
import { formatToman, formatTomanCompact } from "@/lib/money";
import { cn } from "@/lib/utils";
import { useReports, type Report, type ReportDraft } from "@/store/reports";

type View = "week" | "all";

export function AppHome() {
  const reports = useReports((s) => s.reports);
  const addReport = useReports((s) => s.addReport);
  const updateReport = useReports((s) => s.updateReport);
  const deleteReport = useReports((s) => s.deleteReport);

  const today = localISO();
  const [selected, setSelected] = useState(today);
  const [view, setView] = useState<View>("week");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Report | null>(null);
  const [pendingDelete, setPendingDelete] = useState<Report | null>(null);

  const week = useMemo(() => weekDates(selected), [selected]);

  const weekTotals = useMemo(() => {
    const totals: Record<string, number> = {};
    for (const d of week) totals[d] = 0;
    for (const r of reports) {
      if (Object.prototype.hasOwnProperty.call(totals, r.date)) {
        totals[r.date] += r.amount;
      }
    }
    return totals;
  }, [reports, week]);

  const dayReports = useMemo(
    () =>
      reports
        .filter((r) => r.date === selected)
        .sort((a, b) => a.createdAt - b.createdAt),
    [reports, selected],
  );

  const weekSum = useMemo(
    () => Object.values(weekTotals).reduce((a, b) => a + b, 0),
    [weekTotals],
  );

  const monthReports = useMemo(
    () => reports.filter((r) => sameJalaliMonth(r.date, selected)),
    [reports, selected],
  );
  const monthSum = monthReports.reduce((a, r) => a + r.amount, 0);
  const monthDays = new Set(monthReports.map((r) => r.date)).size;
  const daySum = dayReports.reduce((a, r) => a + r.amount, 0);

  const locations = useMemo(() => {
    const set = new Set<string>();
    for (const r of reports) set.add(r.location);
    return [...set];
  }, [reports]);

  const photoDays = useMemo(() => {
    const map: Record<string, boolean> = {};
    for (const r of reports) {
      if ((r.photos ?? []).length > 0) map[r.date] = true;
    }
    return map;
  }, [reports]);

  const lastLocation = reports[0]?.location ?? "";

  function openCreate() {
    setEditing(null);
    setFormOpen(true);
  }

  function openEdit(report: Report) {
    setEditing(report);
    setFormOpen(true);
  }

  function handleSubmit(draft: ReportDraft) {
    if (editing) {
      updateReport(editing.id, draft);
      toast("گزارش ویرایش شد");
    } else {
      addReport(draft);
      toast("گزارش ذخیره شد");
    }
    setEditing(null);
  }

  function confirmDelete() {
    if (!pendingDelete) return;
    deleteReport(pendingDelete.id);
    setPendingDelete(null);
    toast("گزارش حذف شد");
  }

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-lg flex-col px-4 pt-6 pb-10">
      <header className="animate-rise mb-6 flex items-end justify-between gap-4">
        <div>
          <p className="font-display text-4xl leading-none font-semibold tracking-brand text-accent">
            FGC
          </p>
          <p className="mt-2 text-sm text-muted">گزارش کار روزانه</p>
        </div>
        <div className="grid grid-cols-2 rounded-xl bg-surface-2 p-1 shadow-border">
          <button
            type="button"
            onClick={() => setView("week")}
            className={cn(
              "h-10 rounded-lg px-3 text-sm font-medium transition-colors duration-150",
              view === "week" ? "bg-surface text-ink shadow-border" : "text-muted",
            )}
          >
            هفته
          </button>
          <button
            type="button"
            onClick={() => setView("all")}
            className={cn(
              "h-10 rounded-lg px-3 text-sm font-medium transition-colors duration-150",
              view === "all" ? "bg-surface text-ink shadow-border" : "text-muted",
            )}
          >
            همه
          </button>
        </div>
      </header>

      <div className="mb-4 grid grid-cols-3 gap-2">
        <Stat label="این هفته" value={formatTomanCompact(weekSum)} />
        <Stat label="این ماه" value={formatTomanCompact(monthSum)} />
        <Stat label="روز کاری" value={new Intl.NumberFormat("fa-IR").format(monthDays)} />
      </div>

      {view === "week" ? (
        <div className="flex flex-col gap-4">
          <WeekStrip
            dates={week}
            selected={selected}
            today={today}
            totals={weekTotals}
            photoDays={photoDays}
            onSelect={setSelected}
            onPrevWeek={() => setSelected(addDays(week[0] ?? selected, -7))}
            onNextWeek={() => setSelected(addDays(week[0] ?? selected, 7))}
            onToday={() => setSelected(today)}
          />

          <section className="rounded-3xl bg-surface p-3 shadow-border">
            <div className="flex items-start justify-between gap-3 px-2 pt-2 pb-3">
              <div>
                <h2 className="text-base font-medium">{jalaliFull(selected)}</h2>
                {dayReports.length > 0 ? (
                  <p className="mt-1 text-sm text-muted">
                    جمع امروز{" "}
                    <span className="font-medium tabular-nums text-accent">{formatToman(daySum)}</span>
                  </p>
                ) : (
                  <p className="mt-1 text-sm text-muted">هنوز برای این روز چیزی ثبت نشده</p>
                )}
              </div>
            </div>

            {dayReports.length === 0 ? (
              <div className="flex flex-col items-center rounded-xl bg-surface-2 px-4 py-10 text-center">
                <ClipboardList className="size-8 text-subtle" strokeWidth={1.5} />
                <p className="mt-3 font-medium">دفتر این روز خالی است</p>
                <p className="mt-1 max-w-xs text-sm text-muted">
                  مکان کار، عکس یا شرح کار، و مبلغ دریافتی را همین‌جا ثبت کنید.
                </p>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                {dayReports.map((report) => (
                  <ReportCard
                    key={report.id}
                    report={report}
                    onEdit={openEdit}
                    onDelete={setPendingDelete}
                  />
                ))}
              </div>
            )}

            <Button type="button" className="mt-3 w-full" onClick={openCreate}>
              <Plus className="size-4" />
              ثبت گزارش
            </Button>
          </section>
        </div>
      ) : (
        <AllReports reports={reports} onEdit={openEdit} onDelete={setPendingDelete} />
      )}

      <ReportForm
        open={formOpen}
        onOpenChange={(open) => {
          setFormOpen(open);
          if (!open) setEditing(null);
        }}
        date={selected}
        locations={locations}
        editing={editing}
        defaultLocation={lastLocation}
        onSubmit={handleSubmit}
      />

      <Dialog open={Boolean(pendingDelete)} onOpenChange={(open) => !open && setPendingDelete(null)}>
        <DialogContent>
          <DialogTitle className="pe-8 text-lg font-semibold">حذف گزارش</DialogTitle>
          <DialogDescription className="mt-1 text-sm text-muted">
            این گزارش برای همیشه از این دستگاه پاک می‌شود.
          </DialogDescription>
          <div className="mt-5 flex gap-2">
            <Button type="button" variant="danger" className="flex-1" onClick={confirmDelete}>
              حذف
            </Button>
            <Button
              type="button"
              variant="secondary"
              className="flex-1"
              onClick={() => setPendingDelete(null)}
            >
              انصراف
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-surface px-3 py-3 shadow-border">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-1 truncate text-sm font-semibold tabular-nums text-accent">{value}</p>
    </div>
  );
}
