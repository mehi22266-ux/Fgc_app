/** Local calendar date as YYYY-MM-DD (no UTC shift). */
export function localISO(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function parseLocalISO(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y ?? 1970, (m ?? 1) - 1, d ?? 1);
}

export function addDays(iso: string, n: number): string {
  const d = parseLocalISO(iso);
  d.setDate(d.getDate() + n);
  return localISO(d);
}

/** Iranian week starts Saturday. */
export function startOfIranianWeek(iso: string): string {
  const d = parseLocalISO(iso);
  const sinceSaturday = (d.getDay() + 1) % 7;
  return addDays(iso, -sinceSaturday);
}

export function weekDates(iso: string): string[] {
  const start = startOfIranianWeek(iso);
  return Array.from({ length: 7 }, (_, i) => addDays(start, i));
}

export function jalaliParts(iso: string): { year: number; month: number; day: number } {
  const parts = new Intl.DateTimeFormat("en-US-u-ca-persian", {
    year: "numeric",
    month: "numeric",
    day: "numeric",
  }).formatToParts(parseLocalISO(iso));
  const num = (type: Intl.DateTimeFormatPartTypes) =>
    Number(parts.find((p) => p.type === type)?.value ?? 0);
  return { year: num("year"), month: num("month"), day: num("day") };
}

export function sameJalaliMonth(a: string, b: string): boolean {
  const pa = jalaliParts(a);
  const pb = jalaliParts(b);
  return pa.year === pb.year && pa.month === pb.month;
}

export function weekdayLong(iso: string): string {
  return new Intl.DateTimeFormat("fa-IR", { weekday: "long" }).format(parseLocalISO(iso));
}

export function weekdayNarrow(iso: string): string {
  return new Intl.DateTimeFormat("fa-IR", { weekday: "narrow" }).format(parseLocalISO(iso));
}

export function jalaliDay(iso: string): string {
  return new Intl.DateTimeFormat("fa-IR-u-ca-persian", { day: "numeric" }).format(
    parseLocalISO(iso),
  );
}

export function jalaliMonthYear(iso: string): string {
  const d = parseLocalISO(iso);
  const month = new Intl.DateTimeFormat("fa-IR-u-ca-persian", { month: "long" }).format(d);
  const year = new Intl.DateTimeFormat("fa-IR-u-ca-persian", { year: "numeric" }).format(d);
  return `${month} ${year}`;
}

export function jalaliFull(iso: string): string {
  return new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(parseLocalISO(iso));
}

export function jalaliShort(iso: string): string {
  return new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
    day: "numeric",
    month: "long",
  }).format(parseLocalISO(iso));
}

export function jalaliMonthKey(iso: string): string {
  const p = jalaliParts(iso);
  return `${p.year}-${String(p.month).padStart(2, "0")}`;
}
