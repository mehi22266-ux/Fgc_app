const FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹";

export function toFaDigits(value: string | number): string {
  return String(value).replace(/\d/g, (d) => FA_DIGITS[Number(d)] ?? d);
}

export function parseAmount(raw: string): number | null {
  const latin = raw
    .trim()
    .replace(/[۰-۹]/g, (c) => String(FA_DIGITS.indexOf(c)))
    .replace(/[,٬،\s]/g, "")
    .replace(/[^\d.]/g, "");
  if (!latin) return null;
  const n = Number(latin);
  if (!Number.isFinite(n) || n < 0) return null;
  return Math.round(n);
}

export function formatToman(amount: number): string {
  return `${new Intl.NumberFormat("fa-IR").format(amount)} تومان`;
}

export function formatTomanCompact(amount: number): string {
  return new Intl.NumberFormat("fa-IR").format(amount);
}
