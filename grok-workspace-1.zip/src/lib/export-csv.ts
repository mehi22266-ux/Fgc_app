import { jalaliFull, weekdayLong } from "@/lib/dates";
import type { Report } from "@/store/reports";

export function downloadReportsCsv(reports: Report[]) {
  const header = ["تاریخ", "روز هفته", "مکان کار", "کار انجام‌شده", "مبلغ (تومان)"];
  const sorted = [...reports].sort(
    (a, b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt,
  );
  const lines = [
    header.join(","),
    ...sorted.map((r) =>
      [jalaliFull(r.date), weekdayLong(r.date), r.location, r.work, String(r.amount)]
        .map(csvCell)
        .join(","),
    ),
  ];
  const blob = new Blob(["\uFEFF" + lines.join("\n")], {
    type: "text/csv;charset=utf-8;",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "fgc-reports.csv";
  a.click();
  URL.revokeObjectURL(url);
}

function csvCell(value: string): string {
  if (/[",\n]/.test(value)) return `"${value.replaceAll('"', '""')}"`;
  return value;
}
