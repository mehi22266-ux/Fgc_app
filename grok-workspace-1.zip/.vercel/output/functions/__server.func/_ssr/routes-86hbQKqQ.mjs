import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Plus, c as LoaderCircle, d as ClipboardList, f as ChevronRight, i as Search, l as ImagePlus, o as Pencil, p as ChevronLeft, r as Trash2, s as MapPin, t as X, u as Download } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay$1, c as Slot, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-86hbQKqQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DB_NAME = "fgc-media";
var STORE = "images";
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, 1);
		req.onupgradeneeded = () => {
			const db = req.result;
			if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("indexeddb"));
	});
}
async function savePhoto(blob) {
	const id = crypto.randomUUID();
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).put(blob, id);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error ?? /* @__PURE__ */ new Error("save-photo"));
	});
	db.close();
	return id;
}
async function getPhotoBlob(id) {
	const db = await openDb();
	const blob = await new Promise((resolve, reject) => {
		const req = db.transaction(STORE, "readonly").objectStore(STORE).get(id);
		req.onsuccess = () => resolve(req.result ?? null);
		req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("get-photo"));
	});
	db.close();
	return blob;
}
async function deletePhotos(ids) {
	if (ids.length === 0) return;
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		const store = tx.objectStore(STORE);
		for (const id of ids) store.delete(id);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error ?? /* @__PURE__ */ new Error("delete-photos"));
	});
	db.close();
}
async function compressImage(file) {
	const bitmap = await createImageBitmap(file);
	const scale = Math.min(1, 1280 / Math.max(bitmap.width, bitmap.height));
	const width = Math.max(1, Math.round(bitmap.width * scale));
	const height = Math.max(1, Math.round(bitmap.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d");
	if (!ctx) {
		bitmap.close();
		throw new Error("canvas");
	}
	ctx.drawImage(bitmap, 0, 0, width, height);
	bitmap.close();
	const blob = await new Promise((resolve) => {
		canvas.toBlob((b) => resolve(b), "image/jpeg", .74);
	});
	if (!blob) throw new Error("compress");
	return blob;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function PhotoThumb({ id, alt = "عکس کار", className, onClick }) {
	const [src, setSrc] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		let created = null;
		getPhotoBlob(id).then((blob) => {
			if (cancelled || !blob) return;
			created = URL.createObjectURL(blob);
			setSrc(created);
		});
		return () => {
			cancelled = true;
			if (created) URL.revokeObjectURL(created);
		};
	}, [id]);
	if (!src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse bg-surface-2", className),
		"aria-hidden": "true"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("block overflow-hidden", className),
		"aria-label": alt,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt,
			className: "size-full object-cover outline outline-1 -outline-offset-1 outline-ink/10"
		})
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50 focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 active:scale-press", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:bg-accent-hover",
			secondary: "bg-surface-2 text-ink hover:bg-border",
			outline: "bg-surface text-ink shadow-border hover:shadow-border-hover",
			ghost: "text-ink hover:bg-surface-2",
			danger: "bg-danger text-danger-fg hover:bg-danger-hover"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-5",
			icon: "size-11",
			"icon-sm": "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogTitle = DialogTitle$1;
var DialogDescription = DialogDescription$1;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-scrim", "data-[state=open]:animate-overlay-in data-[state=closed]:animate-overlay-out", className),
		...props
	});
}
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("dialog-panel fixed top-1/2 left-1/2 z-50 -translate-x-1/2 -translate-y-1/2", "rounded-3xl bg-surface p-4 text-ink shadow-dialog", "data-[state=open]:animate-dialog-in data-[state=closed]:animate-dialog-out", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
			className: "absolute top-3 left-3 flex size-9 items-center justify-center rounded-lg text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50",
			"aria-label": "بستن",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
				className: "size-4",
				strokeWidth: 2
			})
		})]
	})] });
}
function PhotoLightbox({ ids, index, onIndex }) {
	const open = index !== null && ids.length > 0;
	const current = index === null ? 0 : Math.min(index, Math.max(0, ids.length - 1));
	const id = ids[current];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog$1, {
		open,
		onOpenChange: (next) => {
			if (!next) onIndex(null);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
			className: "lightbox-panel fixed top-1/2 left-1/2 z-50 -translate-x-1/2 -translate-y-1/2 rounded-3xl bg-surface p-3 text-ink shadow-dialog data-[state=open]:animate-dialog-in data-[state=closed]:animate-dialog-out",
			"aria-describedby": void 0,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
					className: "sr-only",
					children: "عکس کار"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
					className: "absolute top-3 left-3 z-10 flex size-9 items-center justify-center rounded-lg bg-bg/70 text-ink transition-colors duration-150 hover:bg-surface-2",
					"aria-label": "بستن",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				}),
				id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoThumb, {
					id,
					className: "aspect-video w-full rounded-xl"
				}) : null,
				ids.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-center justify-between gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							size: "icon-sm",
							onClick: () => onIndex((current - 1 + ids.length) % ids.length),
							"aria-label": "عکس قبلی",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm tabular-nums text-muted",
							children: [
								new Intl.NumberFormat("fa-IR").format(current + 1),
								" از",
								" ",
								new Intl.NumberFormat("fa-IR").format(ids.length)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							size: "icon-sm",
							onClick: () => onIndex((current + 1) % ids.length),
							"aria-label": "عکس بعدی",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
						})
					]
				}) : null
			]
		})] })
	});
}
var FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹";
function parseAmount(raw) {
	const latin = raw.trim().replace(/[۰-۹]/g, (c) => String(FA_DIGITS.indexOf(c))).replace(/[,٬،\s]/g, "").replace(/[^\d.]/g, "");
	if (!latin) return null;
	const n = Number(latin);
	if (!Number.isFinite(n) || n < 0) return null;
	return Math.round(n);
}
function formatToman(amount) {
	return `${new Intl.NumberFormat("fa-IR").format(amount)} تومان`;
}
function formatTomanCompact(amount) {
	return new Intl.NumberFormat("fa-IR").format(amount);
}
function ReportCard({ report, onEdit, onDelete, showDate }) {
	const [lightbox, setLightbox] = (0, import_react.useState)(null);
	const photos = report.photos ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-xl bg-surface-2 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [showDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-xs font-medium text-muted",
						children: showDate
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-1.5 text-sm font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
							className: "size-3.5 shrink-0 text-accent",
							strokeWidth: 2
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: report.location
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "shrink-0 text-base font-semibold tabular-nums text-accent",
					children: formatToman(report.amount)
				})]
			}),
			report.work ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: report.work
			}) : null,
			photos.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-3 gap-1.5",
				children: photos.map((id, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoThumb, {
					id,
					className: "aspect-square rounded-lg",
					onClick: () => setLightbox(i)
				}, id))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "ghost",
					size: "sm",
					onClick: () => onEdit(report),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" }), "ویرایش"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "ghost",
					size: "sm",
					className: "text-danger hover:bg-danger-soft hover:text-danger",
					onClick: () => onDelete(report),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), "حذف"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoLightbox, {
				ids: photos,
				index: lightbox,
				onIndex: setLightbox
			})
		]
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-xl bg-surface-2 px-3 text-base text-ink shadow-border", "placeholder:text-subtle", "transition-[box-shadow] duration-150 ease-out", "focus-visible:outline-none focus-visible:shadow-focus", "disabled:opacity-40", className),
		...props
	});
}
/** Local calendar date as YYYY-MM-DD (no UTC shift). */
function localISO(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function parseLocalISO(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return new Date(y ?? 1970, (m ?? 1) - 1, d ?? 1);
}
function addDays(iso, n) {
	const d = parseLocalISO(iso);
	d.setDate(d.getDate() + n);
	return localISO(d);
}
/** Iranian week starts Saturday. */
function startOfIranianWeek(iso) {
	return addDays(iso, -((parseLocalISO(iso).getDay() + 1) % 7));
}
function weekDates(iso) {
	const start = startOfIranianWeek(iso);
	return Array.from({ length: 7 }, (_, i) => addDays(start, i));
}
function jalaliParts(iso) {
	const parts = new Intl.DateTimeFormat("en-US-u-ca-persian", {
		year: "numeric",
		month: "numeric",
		day: "numeric"
	}).formatToParts(parseLocalISO(iso));
	const num = (type) => Number(parts.find((p) => p.type === type)?.value ?? 0);
	return {
		year: num("year"),
		month: num("month"),
		day: num("day")
	};
}
function sameJalaliMonth(a, b) {
	const pa = jalaliParts(a);
	const pb = jalaliParts(b);
	return pa.year === pb.year && pa.month === pb.month;
}
function weekdayLong(iso) {
	return new Intl.DateTimeFormat("fa-IR", { weekday: "long" }).format(parseLocalISO(iso));
}
function weekdayNarrow(iso) {
	return new Intl.DateTimeFormat("fa-IR", { weekday: "narrow" }).format(parseLocalISO(iso));
}
function jalaliDay(iso) {
	return new Intl.DateTimeFormat("fa-IR-u-ca-persian", { day: "numeric" }).format(parseLocalISO(iso));
}
function jalaliMonthYear(iso) {
	const d = parseLocalISO(iso);
	return `${new Intl.DateTimeFormat("fa-IR-u-ca-persian", { month: "long" }).format(d)} ${new Intl.DateTimeFormat("fa-IR-u-ca-persian", { year: "numeric" }).format(d)}`;
}
function jalaliFull(iso) {
	return new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
		weekday: "long",
		day: "numeric",
		month: "long",
		year: "numeric"
	}).format(parseLocalISO(iso));
}
function downloadReportsCsv(reports) {
	const header = [
		"تاریخ",
		"روز هفته",
		"مکان کار",
		"کار انجام‌شده",
		"مبلغ (تومان)"
	];
	const sorted = [...reports].sort((a, b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt);
	const lines = [header.join(","), ...sorted.map((r) => [
		jalaliFull(r.date),
		weekdayLong(r.date),
		r.location,
		r.work,
		String(r.amount)
	].map(csvCell).join(","))];
	const blob = new Blob(["﻿" + lines.join("\n")], { type: "text/csv;charset=utf-8;" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = "fgc-reports.csv";
	a.click();
	URL.revokeObjectURL(url);
}
function csvCell(value) {
	if (/[",\n]/.test(value)) return `"${value.replaceAll("\"", "\"\"")}"`;
	return value;
}
function AllReports({ reports, onEdit, onDelete }) {
	const [query, setQuery] = (0, import_react.useState)("");
	const filtered = (0, import_react.useMemo)(() => {
		const q = query.trim();
		return [...q ? reports.filter((r) => r.location.includes(q) || r.work.includes(q)) : reports].sort((a, b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt);
	}, [reports, query]);
	const groups = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const r of filtered) {
			const key = jalaliMonthYear(r.date);
			const arr = map.get(key);
			if (arr) arr.push(r);
			else map.set(key, [r]);
		}
		return [...map.entries()];
	}, [filtered]);
	const total = filtered.reduce((sum, r) => sum + r.amount, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-3xl bg-surface p-3 shadow-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "جستجو در مکان یا شرح کار",
					className: "pr-10"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center justify-between gap-3 px-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: filtered.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						"جمع نتایج:",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium tabular-nums text-accent",
							children: formatToman(total)
						})
					] }) : "گزارشی پیدا نشد"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "ghost",
					size: "sm",
					disabled: reports.length === 0,
					onClick: () => downloadReportsCsv(reports),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), "خروجی"]
				})]
			})]
		}), groups.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-3xl bg-surface px-6 py-14 text-center shadow-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: "هنوز گزارشی ثبت نشده"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "از نمای هفته، برای هر روز گزارش کار بنویسید."
			})]
		}) : groups.map(([month, items]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "px-1 text-sm font-medium text-muted",
				children: month
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-3xl bg-surface p-3 shadow-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-2",
					children: items.map((report) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
						report,
						showDate: jalaliFull(report.date),
						onEdit,
						onDelete
					}, report.id))
				})
			})]
		}, month))]
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-sm font-medium text-muted", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-28 w-full resize-y rounded-xl bg-surface-2 px-3 py-3 text-base text-ink shadow-border", "placeholder:text-subtle", "transition-[box-shadow] duration-150 ease-out", "focus-visible:outline-none focus-visible:shadow-focus", "disabled:opacity-40", className),
		...props
	});
}
function ReportForm({ open, onOpenChange, date, locations, editing, defaultLocation, onSubmit }) {
	const locId = (0, import_react.useId)();
	const workId = (0, import_react.useId)();
	const amountId = (0, import_react.useId)();
	const listId = (0, import_react.useId)();
	const fileId = "work-photos";
	const fileRef = (0, import_react.useRef)(null);
	const [location, setLocation] = (0, import_react.useState)("");
	const [work, setWork] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [photos, setPhotos] = (0, import_react.useState)([]);
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		if (editing) {
			setLocation(editing.location);
			setWork(editing.work);
			setAmount(formatTomanCompact(editing.amount));
			setPhotos((editing.photos ?? []).map((id) => ({
				key: id,
				storedId: id
			})));
		} else {
			setLocation(defaultLocation ?? "");
			setWork("");
			setAmount("");
			setPhotos([]);
		}
		setError("");
		setBusy(false);
	}, [
		open,
		editing,
		defaultLocation
	]);
	async function handleFiles(list) {
		if (!list?.length) return;
		const room = 6 - photos.length;
		if (room <= 0) {
			toast(`حداکثر ${toFa(6)} عکس برای هر گزارش`);
			return;
		}
		const files = [...list].filter((f) => f.type.startsWith("image/")).slice(0, room);
		if (files.length === 0) {
			setError("فقط فایل عکس انتخاب کنید.");
			return;
		}
		setBusy(true);
		setError("");
		try {
			const next = [];
			for (const file of files) {
				const blob = await compressImage(file);
				next.push({
					key: crypto.randomUUID(),
					blob,
					url: URL.createObjectURL(blob)
				});
			}
			setPhotos((prev) => [...prev, ...next]);
		} catch {
			setError("آماده‌سازی عکس انجام نشد. دوباره تلاش کنید.");
		} finally {
			setBusy(false);
			if (fileRef.current) fileRef.current.value = "";
		}
	}
	function removePhoto(key) {
		setPhotos((prev) => {
			const target = prev.find((p) => p.key === key);
			if (target?.url) URL.revokeObjectURL(target.url);
			return prev.filter((p) => p.key !== key);
		});
	}
	async function handleSubmit(e) {
		e.preventDefault();
		const loc = location.trim();
		const done = work.trim();
		const parsed = parseAmount(amount);
		if (!loc) {
			setError("مکان کار را بنویسید.");
			return;
		}
		if (!done && photos.length === 0) {
			setError("شرح کار را بنویسید یا عکس کار را بگذارید.");
			return;
		}
		if (parsed === null) {
			setError("مبلغ دریافتی را به‌درستی وارد کنید. اگر پولی نگرفته‌اید صفر بگذارید.");
			return;
		}
		setBusy(true);
		setError("");
		try {
			const savedIds = [];
			for (const photo of photos) if (photo.blob) savedIds.push(await savePhoto(photo.blob));
			else if (photo.storedId) savedIds.push(photo.storedId);
			onSubmit({
				date: editing?.date ?? date,
				location: loc,
				work: done,
				amount: parsed,
				photos: savedIds
			});
			onOpenChange(false);
		} catch {
			setError("ذخیره عکس‌ها انجام نشد. دوباره تلاش کنید.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "pe-8 text-lg font-semibold",
				children: editing ? "ویرایش گزارش" : "ثبت گزارش کار"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
				className: "mt-1 text-sm text-muted",
				children: jalaliFull(editing?.date ?? date)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-5 flex flex-col gap-4",
				onSubmit: (e) => void handleSubmit(e),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: locId,
								children: "مکان کار"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: locId,
								list: listId,
								value: location,
								onChange: (e) => setLocation(e.target.value),
								placeholder: "مثلاً کارگاه ونک",
								autoComplete: "off"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
								id: listId,
								children: locations.map((loc) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: loc }, loc))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: workId,
							children: "کار انجام‌شده"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: workId,
							value: work,
							onChange: (e) => setWork(e.target.value),
							placeholder: "توضیح بنویسید، یا فقط عکس کار را پایین بگذارید"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: fileId,
								children: "عکس کار"
							}),
							photos.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-3 gap-2",
								children: photos.map((photo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [photo.url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: photo.url,
										alt: "",
										className: "aspect-square w-full rounded-xl object-cover outline outline-1 -outline-offset-1 outline-ink/10"
									}) : photo.storedId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoThumb, {
										id: photo.storedId,
										className: "aspect-square w-full rounded-xl"
									}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => removePhoto(photo.key),
										className: "absolute top-1 left-1 flex size-8 items-center justify-center rounded-lg bg-bg/80 text-ink",
										"aria-label": "حذف عکس",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
									})]
								}, photo.key))
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileRef,
								id: fileId,
								type: "file",
								accept: "image/*",
								multiple: true,
								className: "sr-only",
								onChange: (e) => void handleFiles(e.target.files)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								disabled: busy || photos.length >= 6,
								onClick: () => fileRef.current?.click(),
								children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }), photos.length >= 6 ? `حداکثر ${toFa(6)} عکس` : "افزودن عکس از دوربین یا گالری"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: amountId,
							children: "مبلغ دریافتی (تومان)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: amountId,
							inputMode: "numeric",
							value: amount,
							onChange: (e) => setAmount(e.target.value),
							placeholder: "۰",
							className: "tabular-nums"
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-xl bg-danger-soft px-3 py-2 text-sm text-danger",
						role: "alert",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "flex-1",
							disabled: busy,
							children: "ذخیره گزارش"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							className: "flex-1",
							onClick: () => onOpenChange(false),
							children: "انصراف"
						})]
					})
				]
			})
		] })
	});
}
function toFa(n) {
	return new Intl.NumberFormat("fa-IR").format(n);
}
function WeekStrip({ dates, selected, today, totals, photoDays, onSelect, onPrevWeek, onNextWeek, onToday }) {
	const max = Math.max(1, ...dates.map((d) => totals[d] ?? 0));
	const showToday = selected !== today;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-3xl bg-surface p-3 shadow-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "icon-sm",
					onClick: onPrevWeek,
					"aria-label": "هفته قبل",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-1 items-center justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: jalaliMonthYear(selected)
					}), showToday ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onToday,
						className: "rounded-full bg-accent-soft px-2.5 py-1 text-xs font-medium text-accent transition-colors duration-150 hover:bg-accent hover:text-accent-fg",
						children: "امروز"
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "icon-sm",
					onClick: onNextWeek,
					"aria-label": "هفته بعد",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-7 gap-1",
			children: dates.map((iso) => {
				const isSelected = iso === selected;
				const isToday = iso === today;
				const total = totals[iso] ?? 0;
				const bar = total > 0 ? Math.max(18, Math.round(total / max * 100)) : 0;
				const hasPhoto = Boolean(photoDays[iso]);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onSelect(iso),
					className: cn("relative flex min-h-20 flex-col items-center rounded-xl px-0.5 pt-2 pb-1.5 transition-[background-color,color,box-shadow] duration-150", isSelected ? "bg-accent text-accent-fg shadow-border" : "text-ink hover:bg-surface-2"),
					children: [
						hasPhoto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("absolute top-1.5 left-1.5 size-1.5 rounded-full", isSelected ? "bg-accent-fg" : "bg-accent"),
							"aria-label": "دارای عکس"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("text-xs", isSelected ? "text-accent-fg/80" : "text-muted"),
							children: weekdayNarrow(iso)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 text-lg leading-none font-medium tabular-nums",
							children: jalaliDay(iso)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-auto flex h-5 w-full items-end justify-center",
							children: total > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("block w-5 rounded-full", isSelected ? "bg-accent-fg/70" : "bg-accent/70"),
								style: { height: `${Math.round(bar / 100 * 16) + 3}px` },
								title: formatTomanCompact(total)
							}) : isToday && !isSelected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mb-0.5 size-1.5 rounded-full bg-accent" }) : null
						})
					]
				}, iso);
			})
		})]
	});
}
var useReports = create()(persist((set, get) => ({
	reports: [],
	addReport: (draft) => {
		const report = {
			id: crypto.randomUUID(),
			createdAt: Date.now(),
			...draft,
			photos: draft.photos ?? []
		};
		set({ reports: [report, ...get().reports] });
		return report;
	},
	updateReport: (id, draft) => {
		const prev = get().reports.find((r) => r.id === id);
		const nextPhotos = draft.photos ?? [];
		deletePhotos((prev?.photos ?? []).filter((p) => !nextPhotos.includes(p)));
		set({ reports: get().reports.map((r) => r.id === id ? {
			...r,
			...draft,
			photos: nextPhotos
		} : r) });
	},
	deleteReport: (id) => {
		deletePhotos(get().reports.find((r) => r.id === id)?.photos ?? []);
		set({ reports: get().reports.filter((r) => r.id !== id) });
	}
}), {
	name: "fgc-reports",
	version: 2,
	partialize: (state) => ({ reports: state.reports }),
	migrate: (state) => {
		return { reports: ((state ?? {}).reports ?? []).map((r) => ({
			id: r.id,
			date: r.date ?? "",
			location: r.location ?? "",
			work: r.work ?? "",
			amount: r.amount ?? 0,
			photos: r.photos ?? [],
			createdAt: r.createdAt ?? 0
		})) };
	}
}));
function AppHome() {
	const reports = useReports((s) => s.reports);
	const addReport = useReports((s) => s.addReport);
	const updateReport = useReports((s) => s.updateReport);
	const deleteReport = useReports((s) => s.deleteReport);
	const today = localISO();
	const [selected, setSelected] = (0, import_react.useState)(today);
	const [view, setView] = (0, import_react.useState)("week");
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const week = (0, import_react.useMemo)(() => weekDates(selected), [selected]);
	const weekTotals = (0, import_react.useMemo)(() => {
		const totals = {};
		for (const d of week) totals[d] = 0;
		for (const r of reports) if (Object.prototype.hasOwnProperty.call(totals, r.date)) totals[r.date] += r.amount;
		return totals;
	}, [reports, week]);
	const dayReports = (0, import_react.useMemo)(() => reports.filter((r) => r.date === selected).sort((a, b) => a.createdAt - b.createdAt), [reports, selected]);
	const weekSum = (0, import_react.useMemo)(() => Object.values(weekTotals).reduce((a, b) => a + b, 0), [weekTotals]);
	const monthReports = (0, import_react.useMemo)(() => reports.filter((r) => sameJalaliMonth(r.date, selected)), [reports, selected]);
	const monthSum = monthReports.reduce((a, r) => a + r.amount, 0);
	const monthDays = new Set(monthReports.map((r) => r.date)).size;
	const daySum = dayReports.reduce((a, r) => a + r.amount, 0);
	const locations = (0, import_react.useMemo)(() => {
		const set = /* @__PURE__ */ new Set();
		for (const r of reports) set.add(r.location);
		return [...set];
	}, [reports]);
	const photoDays = (0, import_react.useMemo)(() => {
		const map = {};
		for (const r of reports) if ((r.photos ?? []).length > 0) map[r.date] = true;
		return map;
	}, [reports]);
	const lastLocation = reports[0]?.location ?? "";
	function openCreate() {
		setEditing(null);
		setFormOpen(true);
	}
	function openEdit(report) {
		setEditing(report);
		setFormOpen(true);
	}
	function handleSubmit(draft) {
		if (editing) {
			updateReport(editing.id, draft);
			toast("گزارش ویرایش شد");
		} else {
			addReport(draft);
			toast("گزارش ذخیره شد");
		}
		setEditing(null);
	}
	function confirmDelete() {
		if (!pendingDelete) return;
		deleteReport(pendingDelete.id);
		setPendingDelete(null);
		toast("گزارش حذف شد");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh w-full max-w-lg flex-col px-4 pt-6 pb-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "animate-rise mb-6 flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-4xl leading-none font-semibold tracking-brand text-accent",
					children: "FGC"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "گزارش کار روزانه"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 rounded-xl bg-surface-2 p-1 shadow-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setView("week"),
						className: cn("h-10 rounded-lg px-3 text-sm font-medium transition-colors duration-150", view === "week" ? "bg-surface text-ink shadow-border" : "text-muted"),
						children: "هفته"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setView("all"),
						className: cn("h-10 rounded-lg px-3 text-sm font-medium transition-colors duration-150", view === "all" ? "bg-surface text-ink shadow-border" : "text-muted"),
						children: "همه"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "این هفته",
						value: formatTomanCompact(weekSum)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "این ماه",
						value: formatTomanCompact(monthSum)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "روز کاری",
						value: new Intl.NumberFormat("fa-IR").format(monthDays)
					})
				]
			}),
			view === "week" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeekStrip, {
					dates: week,
					selected,
					today,
					totals: weekTotals,
					photoDays,
					onSelect: setSelected,
					onPrevWeek: () => setSelected(addDays(week[0] ?? selected, -7)),
					onNextWeek: () => setSelected(addDays(week[0] ?? selected, 7)),
					onToday: () => setSelected(today)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl bg-surface p-3 shadow-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-start justify-between gap-3 px-2 pt-2 pb-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-base font-medium",
								children: jalaliFull(selected)
							}), dayReports.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: [
									"جمع امروز",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium tabular-nums text-accent",
										children: formatToman(daySum)
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "هنوز برای این روز چیزی ثبت نشده"
							})] })
						}),
						dayReports.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center rounded-xl bg-surface-2 px-4 py-10 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, {
									className: "size-8 text-subtle",
									strokeWidth: 1.5
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-medium",
									children: "دفتر این روز خالی است"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 max-w-xs text-sm text-muted",
									children: "مکان کار، عکس یا شرح کار، و مبلغ دریافتی را همین‌جا ثبت کنید."
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-col gap-2",
							children: dayReports.map((report) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, {
								report,
								onEdit: openEdit,
								onDelete: setPendingDelete
							}, report.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							className: "mt-3 w-full",
							onClick: openCreate,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "ثبت گزارش"]
						})
					]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AllReports, {
				reports,
				onEdit: openEdit,
				onDelete: setPendingDelete
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportForm, {
				open: formOpen,
				onOpenChange: (open) => {
					setFormOpen(open);
					if (!open) setEditing(null);
				},
				date: selected,
				locations,
				editing,
				defaultLocation: lastLocation,
				onSubmit: handleSubmit
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: Boolean(pendingDelete),
				onOpenChange: (open) => !open && setPendingDelete(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "pe-8 text-lg font-semibold",
						children: "حذف گزارش"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "mt-1 text-sm text-muted",
						children: "این گزارش برای همیشه از این دستگاه پاک می‌شود."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "danger",
							className: "flex-1",
							onClick: confirmDelete,
							children: "حذف"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							className: "flex-1",
							onClick: () => setPendingDelete(null),
							children: "انصراف"
						})]
					})
				] })
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-surface px-3 py-3 shadow-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 truncate text-sm font-semibold tabular-nums text-accent",
			children: value
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHome, {});
}
//#endregion
export { Home as component };
