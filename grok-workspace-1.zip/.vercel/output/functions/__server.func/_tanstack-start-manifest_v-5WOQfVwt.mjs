//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-5WOQfVwt.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D2ZWK4PS.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D2ZWK4PS.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Q8ytbbeO.js"]
	}
} });
//#endregion
export { tsrStartManifest };
